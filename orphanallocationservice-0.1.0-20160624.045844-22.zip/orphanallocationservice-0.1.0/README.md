OrphanAllocation REST service
=================================

This file will be packaged with your application, when using `activator dist`.

**Environment variables required to export before running you application**
```
 export APPLICATION_DOCUMENTS_PATH='/document folder path from your machine'
 export APPLICATION_GOLD_DOCUMENTS_PATH='/gold standard document folder path from your machine'
 export GATE_DEV_PATH='/path for Gate developer/
 export GATE_RESOURCE_PATH='/gate-resources path from your machine'
 export SOLR_HOST='52.32.173.118'
 export SOLR_PORT='8983'
 export SOLR_INDEX_PATH='solr'
 export SOLR_COLLECTION='SynerzipRecruitment'
 
``` 

**Steps to run Server**
----
1. Run 'activator' command to build and compile packages from the src folder.
2. type 'run' . It will run server on  port 9000.


**Install mongodb and execute below command in mongo shell**

```sh
> mongo
> use rezoomex
> db.createCollection("users")
> db.users.insert({username:"admin", shaPassword:BinData(0,"sQnzu7wkTrgkQZF+0G1hi5AI3Qmzvv0bXgc5THBqi7mAsdd4Xll27ASbRt9fEyavWi6m0QP9B8lThf+rDKy8hg=="), creationDate : ISODate("2016-04-27T06:42:48.291Z")})
>db.users.ensureIndex({"username" : 1},{"unique": true , "sparse": true})
```

**Default username/password - admin/password**
